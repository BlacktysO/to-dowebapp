fetch("http://localhost:5000/api")
    .then(response => response.json())
    .then(data => {
        document.getElementById("message").innerText = data.message;
    })
    .catch(error => console.error("Error fetching API:", error));