# Full-Stack Web App

This project contains a separate frontend and backend.

## Setup Instructions

1. **Build and run the backend:**
   ```sh
   cd backend
   docker build -t my-backend .
   docker run -d -p 5000:5000 --name backend my-backend
   ```

2. **Build and run the frontend:**
   ```sh
   cd frontend
   docker build -t my-frontend .
   docker run -d -p 80:80 --name frontend my-frontend
   ```

3. **Access the frontend in the browser:**
   ```
   http://your-ec2-public-ip
   ```